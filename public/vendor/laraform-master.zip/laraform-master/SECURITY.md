# Security Policy

**PLEASE DON'T DISCLOSE SECURITY-RELATED ISSUES PUBLICLY, [SEE BELOW](#reporting-a-vulnerability).**

## Reporting a Vulnerability

If you discover a security vulnerability within Laraform, please send an email to us at hello@laraform.io. All security vulnerabilities will be promptly addressed.